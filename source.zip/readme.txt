To compile the simulator, run `make`.

To execute it, run `./sim <name-of-asm-file>`. Available .asm files (in the programs folder) are:
- vectoradd.asm
- vectoradd_unrolled.asm
- gcd.asm
- hammingweight.asm
- hammingweight_unrolled.asm
- fibonacci.asm
- counter.asm